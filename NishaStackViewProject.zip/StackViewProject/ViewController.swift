//
//  ViewController.swift
//  StackViewProject
//
//  Created by Nisha on 07/08/20.
//  Copyright © 2020 Nisha. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var firstView: UIView!
    @IBOutlet weak var firstSubView: UIView!
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var secondSubView: UIView!
    @IBOutlet weak var thirdView: UIView!
    @IBOutlet weak var thirdSubView: UIView!
    @IBOutlet weak var fourthView: UIView!
    @IBOutlet weak var fourthSubView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func hideAllSubViews() {
        firstSubView.isHidden = true
        secondSubView.isHidden = true
        thirdSubView.isHidden = true
        fourthSubView.isHidden = true
    }
    
    
    @IBAction func onFirstViewTap(_ sender: UITapGestureRecognizer) {
        hideAllSubViews()
        firstSubView.isHidden = false
        
        secondView.isHidden = false
        thirdView.isHidden = true
        fourthView.isHidden = true
    }
    
    @IBAction func onSecondViewTap(_ sender: UITapGestureRecognizer) {
        hideAllSubViews()
        secondSubView.isHidden = false
        
        thirdView.isHidden = false
        fourthView.isHidden = true
    }
    
    
    @IBAction func onThirdViewTap(_ sender: UITapGestureRecognizer) {
        hideAllSubViews()
        thirdSubView.isHidden = false
        
        fourthView.isHidden = false
    }
    
    
    @IBAction func onFourthViewTap(_ sender: UITapGestureRecognizer) {
        hideAllSubViews()
        fourthSubView.isHidden = false
    }}
